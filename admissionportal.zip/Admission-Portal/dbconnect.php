<?php
$hostname='192.96.210.62';
$username='cmsadmin';
$password='smartSakec#126';
$database='admission_2016';
$con=mysqli_connect($hostname,$username,$password, $database);
mysqli_select_db($con,$database);
?>